package finalwork2;

/*
 * messages communicate sending messages to each other
 */
public interface Message {
	
}
